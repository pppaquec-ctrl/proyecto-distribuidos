package service;

import dto.request.UserRequest;
import dto.response.UserResponse;

import java.util.List;

public interface IUserService {
    UserResponse create(UserRequest request);
    UserResponse update(Long id, UserRequest request);
    void delete(Long id);
    UserResponse findById(Long id);
    List<UserResponse> findAll();
}
